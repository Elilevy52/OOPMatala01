package ID_206946790_ELI_LEVY;

import java.util.Scanner;

import javax.security.auth.callback.ChoiceCallback;

public class Main {

	public static void main(String[] args) {
		MangerClass manage = new MangerClass();

		// General questions
		String quest1 = "First question";
		String quest2 = "Second question";
		String quest3 = "Third question";
		String quest4 = "Fourth question";
		String quest5 = "Fifth question";
		String quest6 = "Sixth question";
		String quest7 = "Seventh question";
		String quest8 = "Eighth question";

		// Just answers
		String ans1 = "First answer";
		String ans2 = "Second answer";
		String ans3 = "Another answer";
		String ans4 = "And another one";
		String ans5 = "Fifth answer";
		String ans6 = "Sixth answer";
		String ans7 = "Seventh answer";
		String ans8 = "Eighth answer";

		// False answers
		String ansF1 = "False answer #1";
		String ansF2 = "False answer #2";
		String ansF3 = "False answer #3";
		String ansF4 = "False answer #4";
		String ansF5 = "False answer #5";

		// Open answers
		String openAns = "First open answer";
		String openAns2 = "Second open answer";
		String openAns3 = "Third open answer";
		String openAns4 = "Fourth open answer";

		// Create new Multiple Choice Question question objects
		MultilpeChoiceQuestion ameriTest1 = new MultilpeChoiceQuestion(quest1);
		MultilpeChoiceQuestion ameriTest2 = new MultilpeChoiceQuestion(quest2);
		MultilpeChoiceQuestion ameriTest3 = new MultilpeChoiceQuestion(quest3);
		MultilpeChoiceQuestion ameriTest4 = new MultilpeChoiceQuestion(quest4);

		// Add add Multiple Choice Question questions
		manage.addMultilpeChoiceQuestion(ameriTest1);
		manage.addMultilpeChoiceQuestion(ameriTest2);
		manage.addMultilpeChoiceQuestion(ameriTest3);
		manage.addMultilpeChoiceQuestion(ameriTest4);

		// Multiple Choice answers
		MultipeChoiseAnswer ameriAns = new MultipeChoiseAnswer(ans1, true);
		MultipeChoiseAnswer ameriAns2 = new MultipeChoiseAnswer(ans2, true);
		MultipeChoiseAnswer ameriAns3 = new MultipeChoiseAnswer(ans3, true);
		MultipeChoiseAnswer ameriAns4 = new MultipeChoiseAnswer(ans4, true);
		MultipeChoiseAnswer ameriAns5 = new MultipeChoiseAnswer(ans5, true);
		MultipeChoiseAnswer ameriAns6 = new MultipeChoiseAnswer(ans6, true);
		MultipeChoiseAnswer ameriAns7 = new MultipeChoiseAnswer(ans7, true);
		MultipeChoiseAnswer ameriAns8 = new MultipeChoiseAnswer(ans8, true);
		MultipeChoiseAnswer ameriAnsF1 = new MultipeChoiseAnswer(ansF1, false);
		MultipeChoiseAnswer ameriAnsF2 = new MultipeChoiseAnswer(ansF2, false);
		MultipeChoiseAnswer ameriAnsF3 = new MultipeChoiseAnswer(ansF3, false);
		MultipeChoiseAnswer ameriAnsF4 = new MultipeChoiseAnswer(ansF4, false);
		MultipeChoiseAnswer ameriAnsF5 = new MultipeChoiseAnswer(ansF5, false);

		// More than one is correct:
		ameriTest1.addAnswer(ameriAns);
		ameriTest1.addAnswer(ameriAns2);
		ameriTest1.addAnswer(ameriAns3);
		ameriTest1.addAnswer(ameriAns4);
		ameriTest1.addAnswer(ameriAnsF1);
		ameriTest1.addAnswer(ameriAnsF4);

		// All false
		ameriTest2.addAnswer(ameriAnsF1);
		ameriTest2.addAnswer(ameriAnsF2);
		ameriTest2.addAnswer(ameriAnsF3);
		ameriTest2.addAnswer(ameriAnsF4);
		ameriTest2.addAnswer(ameriAnsF5);

		// Only one question is true
		ameriTest3.addAnswer(ameriAns5);
		ameriTest3.addAnswer(ameriAnsF1);
		ameriTest3.addAnswer(ameriAnsF2);
		ameriTest3.addAnswer(ameriAnsF3);
		ameriTest3.addAnswer(ameriAnsF4);

		// more than one is correct #2
		ameriTest4.addAnswer(ameriAns6);
		ameriTest4.addAnswer(ameriAns7);
		ameriTest4.addAnswer(ameriAns8);
		ameriTest4.addAnswer(ameriAnsF3);
		ameriTest4.addAnswer(ameriAnsF4);

		// Open questions + Answers
		manage.addOpenQuestion(quest5, openAns);
		manage.addOpenQuestion(quest6, openAns2);
		manage.addOpenQuestion(quest7, openAns3);
		manage.addOpenQuestion(quest8, openAns4);

		Scanner input = new Scanner(System.in);
		int choice = 0;
		int innerOP;
		int questionNum = 0;
		int amountOfQuestions =0;
		String menu = ("\n--------Exam creator--------\n" + "-----Select option:-----\n"
				+ "[1] - Show all questions/answers that exist.\n" + "[2] - Add a new question/answer.\n"
				+ "[3] - Update an existing question.\n" + "[4] - Update an existing answer.\n"
				+ "[5] - Delete an existing answer.\n" + "[6] - Create an exam manually.\n"
				+ "[7] - Create an exam automatically.\n" + "\n[8] - Exit.\n" + "Enter your choice: ");
		do {
			System.out.println(menu);
			choice = input.nextInt();
			input.nextLine();
			switch (choice) {
			case 1:
				System.out.println("-----Show all questions menu-----");
				System.out.println("[1] - Show all questions.");
				System.out.println("[2] - Show only American-type questions (With their correct answers).");
				System.out.println("[3] - Show only Open-type questions.");
				System.out.println("[4] - Show available questions only.");
				System.out.println(
						"[-1] - Go back to main menu." + "\n(You can type '-1' at any time to go back to main menu).");
				do {
					innerOP = input.nextInt();
					switch (innerOP) {
					case 1:
						manage.printAllQuestionAndAnswers();
						break;
					case 2:
						manage.printOnlyMultilpeChoiceQuestions();
						break;
					case 3:
						manage.printOnlyOpenQuestions();
						break;
					case 4:
						manage.printAllQuestions();
						break;
					}
				} while (innerOP != -1);
				break;

			case 2:
				System.out.println("----Add a question-----" + "\n[1] - Add an Multilpe Choice - type question."
						+ "\n[2] - Add an open - type question." + "\n[-1] - To go back to main menu."
						+ "\n(You can type '-1' at any time to go back to main menu).");
				do {
					innerOP = input.nextInt();
					input.nextLine();
					switch (innerOP) {
					case 1:
						System.out.println("Please enter your question below: ");
						String ameriQuestion = input.nextLine();
						MultilpeChoiceQuestion ameriC = new MultilpeChoiceQuestion(ameriQuestion);
						manage.addMultilpeChoiceQuestion(ameriC);
						System.out.println("How many answers do you want to add? (2 to 6) ");
						int answersAmount = input.nextInt();
						input.nextLine();
						for (int i = 0; i < answersAmount; i++) {
							System.out.println("Please enter answer number " + (i + 1) + ": ");
							String answer = input.nextLine();
							System.out.println("Is it a correct answer or not? (true/false): ");
							boolean isTrue = input.nextBoolean();
							System.out.println(ameriC.addAnswer(new MultipeChoiseAnswer(answer, isTrue)));
							input.nextLine();
						}
						break;
					case 2:
						System.out.println("Please enter your question below: ");
						String question = input.nextLine();
						System.out.println("Please enter an answer: ");
						String answer = input.nextLine();
						System.out.println(manage.addOpenQuestion(question, answer));
						break;
					}
				} while (innerOP != -1);
				break;

			case 3:

				do {
					System.out.println(
							"See the full list of questions & answers? y/Y" + "\nTo go back to main menu 'n/N.");
					char newChoice = input.next().charAt(0);
					if (newChoice == 'y' || newChoice == 'Y') {
						manage.printAllQuestions();
					} else if (newChoice == 'n' || newChoice == 'N') {
						innerOP = -1;
						break;
					}
					System.out.println("Please choose the question number you want to update: ");
					int updateChoice = input.nextInt();
					input.nextLine();
					System.out.println("Enter new text below: ");
					String newQuestion = input.nextLine();
					System.out.println(manage.updateAnExistingQuestion(updateChoice, newQuestion));
					break;

				} while (innerOP != -1);
				break;

			case 4:
				System.out.println("Would you like to update an Multilpe Choice answer or Open answer?"
						+ "\nType [1] for Multilpe Choise, \nType [2] for Open." + "\n[-1] - To go back to main menu.");
				do {
					innerOP = input.nextInt();
					input.nextLine();
					switch (innerOP) {
					case 1:
						System.out.println(
								"See the full list of questions & answers? y/Y" + "\nTo go back to main menu 'n/N.");
						char newChoice1 = input.next().charAt(0);
						if (newChoice1 == 'y' || newChoice1 == 'Y') {
							manage.printOnlyMultilpeChoiceQuestions();
						} else if (newChoice1 == 'n' || newChoice1 == 'N') {
							innerOP = -1;
							break;
						}
						System.out.println("Please select from which question you want to update an answer: ");
						questionNum = input.nextInt();
						input.nextLine();
						manage.getMultipeChoiseAnswer(questionNum);
						System.out.println("Please select which answer: ");
						int answerNum = input.nextInt();
						input.nextLine();
						System.out.println("Please enter the new answer: ");
						String newAnswer = input.nextLine();
						System.out.println(manage.updateAnAnswer(questionNum, answerNum, newAnswer));
						break;
					case 2:
						System.out.println(
								"See the full list of questions & answers? y/Y" + "\nTo go back to main menu 'n/N.");
						char newChoice2 = input.next().charAt(0);
						if (newChoice2 == 'y' || newChoice2 == 'Y') {
							manage.printOnlyOpenQuestions();
						} else if (newChoice2 == 'n' || newChoice2 == 'N') {
							innerOP = -1;
							break;
						}

						System.out.println("Please select from which question you want to update an answer: ");
						int questionNum1 = input.nextInt();
						input.nextLine();
						System.out.println("Please enter the new answer: ");
						String newAnswer1 = input.nextLine();
						System.out.println(manage.updateAnAnswer(questionNum1, questionNum, newAnswer1));
						break;
					}
				} while (innerOP != -1);
				break;

			case 5:
				do {

					System.out
							.println("See the full list of questions&answers? y/Y" + "\nTo go back to main menu 'n/N.");
					char newChoice2 = input.next().charAt(0);
					if (newChoice2 == 'y' || newChoice2 == 'Y') {
					} else if (newChoice2 == 'n' || newChoice2 == 'N') {
						innerOP = -1;
						break;
					}
					System.out.println("Can only delete from American-type questions.");
					manage.printAllQuestions();

					System.out.println("Please select from which question you want to delete an answer: ");
					int questionNum1 = input.nextInt();
					input.nextLine();
					while (!manage.checkInstanceofQuestion(questionNum1)) {
						System.out.println("Cannot delete from an Open Question, select a different one: ");
						questionNum1 = input.nextInt();
						input.nextLine();
					}
					manage.printSelectedMultipeChoiseAnswers(questionNum1);
					System.out.println("Please select which answer: ");
					int answerNum1 = input.nextInt();
					input.nextLine();
					System.out.println(manage.deleteAnExistingAnswer(questionNum1, answerNum1));
					break;
				} while (innerOP != -1);
				break;

			case 6:
			
				System.out.println("How many questions do you want in your exam? ");
				amountOfQuestions =  input.nextInt();
				manage.setSize(amountOfQuestions);
				manage.printAllQuestions();
				int answersAmount = 0;
				int[] answersArray = new int[0];
				System.out.println("\nPlease choose the question you wish to add: ");
				for (int i = 0; i < amountOfQuestions; i++) {
					 questionNum =  input.nextInt();	
						if (!manage.checkInstanceofQuestion(questionNum)) {
							manage.addQuestionToManualExam(questionNum, null);
						}
						else {
							System.out.println("Please choose the amount of answers you want for the question: ");
							answersAmount =  input.nextInt();	
							answersArray = new int[answersAmount];
							System.out.println("These are the answers:");
							manage.getMultipeChoiseAnswer(questionNum);
							System.out.println("Please select the answers you want: ");
							for (int j = 0; j < answersArray.length; j++) {
								answersArray[j] =  input.nextInt();	
							}
							manage.addQuestionToManualExam(questionNum, answersArray);
							System.out.println("Please chose the next question and answers.");
							
						}
				}
				manage.createManualExamAndSendToPrint(answersArray, amountOfQuestions);
				break;

			case 7:

				System.out.println("How many questions would you like in your exam? ");
				System.out.println("There are only: " + manage.checkAllQuestionLength() + " Questions available.");
				int questAmount =  input.nextInt();
				if (questAmount < 0 || questAmount > manage.checkAllQuestionLength()) {
					System.out.println("Invalid amount of question, please select again: ");
					questAmount = input.nextInt();;
				}
				manage.autoCreateExam(questAmount);
				break;
					
			default:
				if (choice != 8) {
					System.out.println("Invalid option, Please try again.");
				}
		
			}
		} while (choice != 8);
		System.out.println("Exiting program...Thank you!");
		input.close();

	}
}